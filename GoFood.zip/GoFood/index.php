<?php

    require_once('core/view.php');
    require_once('core/controller.php');
    require_once('core/app.php');
    require_once('core/model.php');
    require_once('core/database.php');
    require_once('config/constants.php');
    require_once('public/tcpdf/tcpdf.php');
 

    $app = new App();
?>