<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GF</title>
</head>
<body  style = "background-image: url(<?=URL?>/public/img/fondoV2.png)">
<?php
require_once ('views/header.php');
?>
<h1>ESTA ES LA PAGINA PRINCIPAL</h1>
<div class="col-10 mt-4">
                <h1 class="text-center text-primary">Bienvenid@ <?=$_SESSION['usuario'] ?></h1>
                
            </div>



<?php
require_once ('views/footer.php');
?>
  
</body>
</html>