<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGING</title>    
</head>
<body>
  
    
    <div class="container">
    <div class="row align-items-center justify-content-center vh-100">
        <div class="col-lg-4 col-md-4 col-sm-12 card">
            <div class="card-body">
                <h2 class="text-center pt-3">Login</h2>  
                <form action="<?=URL?>inicio/login" method="POST">
                    Usuario
                    <input type="text" class="form-control" name="txtUsuario">
                    id_usuario
                    <input type="password" class="form-control" name="txtContrasena">
                    <button class="btn btn-primary mt-2 btn-block btn-sm">Iniciar sesión</button>
                </form> 
            </div>                               
        </div> 
    </div>
</div>
<?php
    require_once('views/footer.php');
    ?>  
