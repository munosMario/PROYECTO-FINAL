<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
   
    
    <title>GF</title>
</head>
<body style = "background-image: url(<?=URL?>/public/img/fondoV2.png)" >
<?php
require_once ('views/header.php');
// echo '<pre>';
// print_r($this->productos);
?>

<!-- <img src="<?=URL?>public/img/fondoV2.png" class=" img-fluid"> -->
<div class="container">
<div class="row justify-content-center">

<div class="col-10 mt-4">
<table id="table_id" class="table table-dark table-hover"  >
<a href="<?=URL?>producto/agregar" class="btn btn-block btn-primary mt-3">Agregar producto</a>   
  <thead>
    <tr>
     
      <th scope="col">ID</th>
      <th scope="col">Nombre</th>
      <th scope="col">Proveedor</th>
      <th scope="col">tipo</th>
      <th scope="col">precio</th>
      <th scope="col">Fecha Ingreso</th>
      <th scope="col">Fecha Caducida</th>
    </tr>
  </thead>
  <tbody>
    <?php

    $productos = $this -> productos;
    for ($i=0; $i < count($productos); $i++) { 
      $urlModificar = URL.'producto/modificar?id_producto='.$productos[$i]['id_producto'];
      $urlEliminar = URL.'producto/eliminar?id_producto='.$productos[$i]['id_producto'];
     
      echo '<tr> 
     <td>'.$productos[$i]['id_producto'].'</td>
     <td>'.$productos[$i]['nombre'].'</td>
     <td>'.$productos[$i]['proveedor'].'</td>
     <td>'.$productos[$i]['tipo'].'</td>
     <td>'.$productos[$i]['precio'].'</td>
     <td>'.$productos[$i]['fecha_entrada'].'</td>
     <td>'.$productos[$i]['fecha_expiracion'].'</td>
     <td>
     <div class= "btn-group btn_group-sm">
     <a  href="'.$urlEliminar.'" type="button" class="btn btn-secondary" id="btnEliminar">Eliminar</a>
    <a  href="'.$urlModificar.'" type="button" class="btn btn-success">Modificar</a>
    </div>
    </td>   
</tr>';
   
    }
    ?>
 
    </tbody>

</table>
</div>
</div>
</div>
<?php
require_once ('views/footer.php');?>

<script src = "<?=URL?>public/js/productos.js"></script>

  
</body>
</html>


