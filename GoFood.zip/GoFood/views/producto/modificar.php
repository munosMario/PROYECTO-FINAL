<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar</title>
   

     <!--DataTables css-->
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.0/css/jquery.dataTables.css">
    <!--Swiper.js-->
    <link rel="stylesheet"href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>
    <!--Tailwind css-->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="<?=URL?>/public/css/style.css">
	<!--VALIDETTA
	<link rel="stylesheet" href="public/css/validetta.min,css" class="">-->
    <!--Google font-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@700&family=Joti+One&display=swap" rel="stylesheet">
    
    
</head>
<body style = "background-image: url(<?=URL?>)" >
<?php
require_once ('views/header.php');
// echo '<pre>';
//se consulta el orden de los items mediante un array
// print_r($this->productos);
?>




<!-- component -->

		<!-- Container -->
		<div class="">
			<div class="">
				<!-- Row -->
				<div class="">

					<div class="">
						<h3 class="">Modificar Producto</h3>
                        <?php
                        // arreglo en pantalla
                                $productos = $this->datos;
                               

                        ?>
						<form action ="<?=URL?>producto/modificar" method="POST" class="" id="frmProducto">
							<div class="">
                            <div class="">
									<label class="block mb-2 text-sm font-bold text-gray-700" for="firstName">
									Codigo Producto
									</label>
									<input class="w-full px-3 py-2 text-sm leading-tight text-gray-700 border 
                  rounded shadow appearance-none focus:outline-none focus:shadow-outline" id="firstName"
									name="txtCodigo" type="text" placeholder="First Name" value="<?=$productos[0]?>">
								</div>

                <div class="mb-4 md:mr-2 md:mb-0">
									<label class="block mb-2 text-sm font-bold text-gray-700" for="firstName">
										Nombre
									</label>
									<input class="w-full px-3 py-2 text-sm leading-tight text-gray-700 border 
                  rounded shadow appearance-none focus:outline-none focus:shadow-outline" id="firstName"
									name="txtNombre" type="text" placeholder="First Name" value="<?=$productos[1]?>">
								</div>

                <div class="mb-4 md:mr-2 md:mb-0">
									<label class="block mb-2 text-sm font-bold text-gray-700" for="firstName">
										Proveedor
									</label>
									<input class="w-full px-3 py-2 text-sm leading-tight text-gray-700 border 
                  rounded shadow appearance-none focus:outline-none focus:shadow-outline" id="firstName"
									name="txtProveedor"	type="text" placeholder="First Name" value="<?=$productos[2]?>">
								</div>

                <div class="mb-4 md:mr-2 md:mb-0">
									<label class="block mb-2 text-sm font-bold text-gray-700" for="firstName">
										Tipo Producto
									</label>
									<input class="w-full px-3 py-2 text-sm leading-tight text-gray-700 border 
                  rounded shadow appearance-none focus:outline-none focus:shadow-outline" id="firstName"
									name="txtTipo" type="text" placeholder="First Name" value="<?=$productos[3]?>">
								</div>

                <div class="mb-4 md:mr-2 md:mb-0">
									<label class="block mb-2 text-sm font-bold text-gray-700" for="firstName">
										Precio
									</label>
									<input class="w-full px-3 py-2 text-sm leading-tight text-gray-700 border 
                  rounded shadow appearance-none focus:outline-none focus:shadow-outline" id="firstName"
									name="txtPrecio" type="number" placeholder="First Name" value="<?=$productos[4]?>">
							</div>
                </div>

                 <!-- No funciona el ingreso de fecha -->
							<div class="mb-4 md:flex md:justify-between">
								<div class="md:ml-2">
									<label class="block mb-2 text-sm font-bold text-gray-700" >
										Fecha de entrada
                                  
                                    </label>
									<input class="w-full px-3 py-2 mb-3 text-sm leading-tight text-gray-700 border 
                                    rounded shadow appearance-none focus:outline-none focus:shadow-outline"
									name = "txtEntrada"  type="datetime-local" value="<?=$productos[5]?>">
								</div>

                <div class="md:ml-2">
                   
									<label class="block mb-2 text-sm font-bold text-gray-700" >
										Fecha de expiración
									</label>
									<input class="w-full px-3 py-2 mb-3 text-sm leading-tight text-gray-700 border 
                                    rounded shadow appearance-none focus:outline-none focus:shadow-outline"
									id="" name="txtExpi" type="date" value="<?=$productos[6]?>">
								</div>
							</div>

							<div class="mb-6 text-center">
								<button
									class="w-full px-4 py-2 font-bold text-white bg-blue-500 rounded-full hover:bg-blue-700 focus:outline-none focus:shadow-outline"
									type="button" id="btnModificar">
									Modificar
								</button>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>
	</body>
   
  

 
<?php
require_once ('views/footer.php');?>
<script src = "<?=URL?>public/js/productos.js"></script>


  
</body>
</html>