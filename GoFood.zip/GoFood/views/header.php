<nav class="navbar navbar-expand-lg navbar-info bg-dark">
  <a class="navbar-brand" href="#">GF</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="<?=URL?>inicio/home">Inicio <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
      <a class="nav-link" href="<?=URL?>inicio/logout">Salir</a>
      </li>



      
      
      <?php
      if ($_SESSION['rol']==1) {
        $url=URL;
        echo '
        
      
        
        
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Productos
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="'.$url.'producto/index">Productos</a>
          
        </div>
      </li>';
    } elseif ($_SESSION['rol']==2) {
      $url=URL;
      echo' <a class="nav-link" href="'.$url.'informe/pedidos" target="_blank">reporte de Pedidos</a>
      <a class="nav-link" href="'.$url.'informe/DetallesCliente" target="_blank">reporte de  clientes </a>';
    }elseif ($_SESSION['rol']==3) 
      
    {
      $url=URL;

      echo ' <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Reportes
      </a>
      <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        
      <a class="nav-link" href="'.$url.'informe/pedidos" target="_blank">Pedidos</a>
      <a class="nav-link" href="'.$url.'informe/detalles" target="_blank">Detalles</a>
      <a class="nav-link" href="'.$url.'informe/DetallesCliente" target="_blank"> clientes </a>
      <a class="nav-link" href="'.$url.'informe/existencia" target="_blank"> productos en existencia </a>
      </div>
    </li>';

    }
        
      
      
      
      
      ?>



     








     
    </ul>
  </div>
</nav>