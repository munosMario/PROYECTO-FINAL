<?php
define('URL','http://localhost/GoFood/')

?>